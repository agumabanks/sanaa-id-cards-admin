<?php $__env->startSection('content'); ?>
am work
<div class="p-12 max-w-2xl mx-auto m-8 bg-slate-200 rounded-md">
    <form method="POST" action="/upload2" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="m-2 p-2">
            <label >title</label>
            <input type="text" name='title' />
        </div>
        <div class="m-2 p-2">
                <label for="image">image</label>
                <input type="file" name="image"/>
        </div>
        <button type="submit" class="btn btn-primary w-24 mr-1 mb-2">Save</button>
     </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/banksibrah/Desktop/sanaa-id-cards-admin/resources/views/website/work.blade.php ENDPATH**/ ?>