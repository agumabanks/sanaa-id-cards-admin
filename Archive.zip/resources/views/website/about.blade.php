@extends('layouts.app')
@section('content')
about
@endsection